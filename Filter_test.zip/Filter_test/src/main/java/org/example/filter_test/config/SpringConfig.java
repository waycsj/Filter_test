package org.example.filter_test.config;

import org.example.filter_test.filter.LogFilter;
import org.example.filter_test.interceptor.LogInterceptor;
import org.example.filter_test.interceptor.LoginInterceptor;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//@Configuration
//public class SpringConfig implements WebMvcConfigurer {
//  @Override
//  public void addInterceptors(InterceptorRegistry registry) {
//    WebMvcConfigurer.super.addInterceptors(registry);
//    registry.addInterceptor(new LoginInterceptor())
//            .addPathPatterns("/**")
//            .order(1);
//    registry.addInterceptor(new LogInterceptor())
//            .order(2)
//            .addPathPatterns("/**")
//            .excludePathPatterns("/members/register", "/members/login", "/posts");
//  }
//}

//public class SpringConfig {
//
//  @Bean
//  public FilterRegistrationBean logfilterRB() {
//    //frb.setFilter(new LogFilter());//세터주입방식이다  //생성자주입방식 쓰니까 주석처리함
//    FilterRegistrationBean frb = new FilterRegistrationBean(new LogFilter());//생성자주입방식 이걸 쓰겠다
//    frb.addUrlPatterns("/*");
//    frb.setOrder(1);
////    FilterRegistrationBean frb2 = new FilterRegistrationBean(new LogFilter());
////    frb2.addUrlPatterns("/*");
////    frb2.setOrder(2);
//    return frb;
//  }
//
//  @Bean
//  public FilterRegistrationBean loginfilterRB() {
//    FilterRegistrationBean frb = new FilterRegistrationBean(new LogFilter());
//    frb.addUrlPatterns("/members/register", "/members/login", "/members/logout");
//    frb.setOrder(2);
//    return frb;
//  }
//}
