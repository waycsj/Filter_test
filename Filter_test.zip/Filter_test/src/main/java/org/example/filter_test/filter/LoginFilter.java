package org.example.filter_test.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;

@Slf4j
public class LoginFilter implements Filter {//로그인 여부를 체크하는 필터

  @Override
  public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
    HttpServletRequest req = (HttpServletRequest) servletRequest;
    HttpSession session = req.getSession(false);
    //false = 기존 세션이 있으면 있는 세션을 반환, 없으면 null
    //true = 세션이 없으면 세션을 생성, 세션이 있으면 세션을 반환한다.


    if (session != null) {
      log.info("로그인 되었습니다.");
      filterChain.doFilter(servletRequest, servletResponse);
    }else{
      log.info("로그인되지 않았습니다.");//뒤에 필터나 디스패처한테 로그인 정보를 전달하지 않음
      filterChain.doFilter(servletRequest, servletResponse);
    }
  }
}
